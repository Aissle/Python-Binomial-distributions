from setuptools import setup

setup(name='distributions_mini',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_mini'],
      author= 'Idris Aminat',
      authors_email='idris.oaminat@gmail.com',
      zip_safe=False
      )